#include "relationgui.h"

RelationGui::RelationGui()
{

}
