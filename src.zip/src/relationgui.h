#ifndef RELATIONGUI_H
#define RELATIONGUI_H


class RelationGui
{
public:
    RelationGui();
};

#endif // RELATIONGUI_H
