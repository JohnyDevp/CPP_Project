#include "UMLSeqClass.hpp"

UMLSeqClass::UMLSeqClass(QString name, QString className, int Xcoord) : Element(name), className(className), Xcoord(Xcoord) {}

UMLSeqClass::~UMLSeqClass() {}

UMLSeqClass::UMLSeqClass() : Element(DEFAULT_NAME) {}

void UMLSeqClass::write(QJsonObject &json) const
{
    Element::write(json);

    json[classNameName] = className;

    json[xcoordName] = Xcoord;
}

void UMLSeqClass::read(const QJsonObject &json)
{

    Element::read(json);

    if (json.contains(classNameName) && json[classNameName].isString())
    {
        className = json[classNameName].toString();
    }

    if (json.contains(xcoordName) && json[xcoordName].isDouble())
    {
        Xcoord = json[xcoordName].toInt();
    }
}
