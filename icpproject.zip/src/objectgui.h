#ifndef OBJECTGUI_H
#define OBJECTGUI_H

#include <QGraphicsItem>
#include <QPainter>
#include <QDebug>

class ObjectGUI : public QGraphicsItem
{
public:
    ObjectGUI();
    ~ObjectGUI();

    QRectF boundingRect() const;
    void paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget);

    /**
     * @brief isSelected
     */
    bool isSelected = false;
protected:
    void mousePressEvent(QGraphicsSceneMouseEvent *event);
    void mouseReleaseEvent(QGraphicsSceneMouseEvent *event);
};

#endif // OBJECTGUI_H
