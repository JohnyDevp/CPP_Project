#include "interfaceobjectgui.h"

InterfaceObjectGUI::InterfaceObjectGUI()
{

}
