#include "objectgui.h"
#include "diagraminterface.h"

#include <QGraphicsSceneMouseEvent>
ObjectGUI::ObjectGUI()
{
    //make the object movable
    setFlag(QGraphicsItem::ItemIsMovable);
    //set whether it is selected or not
    this->isSelected = false;
}

QRectF ObjectGUI::boundingRect() const
{
    return QRectF(0,0,100,100);
}

void ObjectGUI::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    QRectF rec = boundingRect();
    QBrush brush(Qt::blue);

    //handle whether it is selected or not
    if (this->isSelected){
        brush.setColor(Qt::red);
    }else {
        brush.setColor(Qt::blue);
    }

    painter->fillRect(rec, brush);
    painter->drawText(10,10,"First class");
    painter->drawLine(0,40,0,40);
    painter->drawLine();
    painter->drawRect(rec);
}

void ObjectGUI::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    this->isSelected = !isSelected;
    std::cout << event->scenePos().x() << "  ahoj" <<std::endl;
    update();
    QGraphicsItem::mousePressEvent(event);
}

//void ObjectGUI::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
//{
//    //this->isSelected = false;
//    update();
//    QGraphicsItem::mouseReleaseEvent(event);
//}

ObjectGUI::~ObjectGUI(){

}
