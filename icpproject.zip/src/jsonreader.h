#ifndef JSONREADER_H
#define JSONREADER_H


class JsonReader
{
public:
    JsonReader();
};

#endif // JSONREADER_H
