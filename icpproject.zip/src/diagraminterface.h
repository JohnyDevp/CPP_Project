#ifndef DIAGRAMINTERFACE_H
#define DIAGRAMINTERFACE_H

#include "src/objectgui.h"
#include <iostream>
#include <vector>

class DiagramInterface
{
public:
    DiagramInterface();

    std::vector<ObjectGUI> classGUIList;
};

#endif // DIAGRAMINTERFACE_H
