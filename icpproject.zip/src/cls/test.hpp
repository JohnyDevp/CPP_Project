#pragma once
#include <iostream>

class test{
private:
    int age;
public:
    test();
    ~test();
    void sayHello();

};
