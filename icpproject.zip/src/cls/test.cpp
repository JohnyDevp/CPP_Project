#include "test.hpp"

test::test(){
    this->age = 21;
}

test::~test(){

}

void test::sayHello(){
    std::cout << "hey\n";
}

