#include "Mess.hpp"

Message::Message(/* args */)
{
}

Message::~Message()
{
}