#pragma once

class Message
{
private:
    /* data */
public:
    Message(/* args */);
    ~Message();
};
