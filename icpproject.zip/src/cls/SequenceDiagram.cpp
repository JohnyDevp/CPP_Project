#include "SequenceDiagram.hpp"

SequenceDiagram::SequenceDiagram(/* args */)
{
}

SequenceDiagram::~SequenceDiagram()
{
}