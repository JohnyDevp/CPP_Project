#pragma once

class SequenceDiagram
{
private:
    /* data */
public:
    SequenceDiagram(/* args */);
    ~SequenceDiagram();
};


