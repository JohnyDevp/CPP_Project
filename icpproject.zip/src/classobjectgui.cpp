#include "classobjectgui.h"

ClassObjectGUI::ClassObjectGUI()
{

}
