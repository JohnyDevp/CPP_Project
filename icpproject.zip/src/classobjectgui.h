#ifndef CLASSOBJECTGUI_H
#define CLASSOBJECTGUI_H


class ClassObjectGUI
{
public:
    ClassObjectGUI();
};

#endif // CLASSOBJECTGUI_H
