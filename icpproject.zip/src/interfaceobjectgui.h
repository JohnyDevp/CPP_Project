#ifndef INTERFACEOBJECTGUI_H
#define INTERFACEOBJECTGUI_H


class InterfaceObjectGUI
{
public:
    InterfaceObjectGUI();
};

#endif // INTERFACEOBJECTGUI_H
