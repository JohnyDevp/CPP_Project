/**
 * @file sequencemessagegui.cpp
 * @author xholan11
 * @brief Represents Message in Sequence diagram
 * @date 2022-05-05
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "sequencemessagegui.h"

SequenceMessageGUI::SequenceMessageGUI()
{
}
